<?php
    $server = "localhost";
    $user ="root";
    $password ="";
    $bddados = "bdagenda";
    $conn = mysqli_connect($server,$user,$password,$bddados);
?>