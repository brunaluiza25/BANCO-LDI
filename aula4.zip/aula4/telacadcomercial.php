<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styleuser.css">
    <title> Comercial</title>
</head>
<body>
<section>
    <form action="inserircomercial.php" method="POST">
         Nome:
        <input type="text" name="cxnome"/><br/>
         Comercio:
        <input type="text" name="cxcomercio"/><br/>
         Telefone:
        <input type="text" name="cxtelefone"/><br/>
        WhatsApp:
        <input type="text" name="cxwhats"/><br/>
        <input type="submit" value="Gravar">
    </form>




</section>
</body>
</html>