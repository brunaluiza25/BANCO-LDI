<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="stylesheet" href="css/stylemenu.css">
</head>
<body>
    <section id="cxprincipal">
        <header id="banner"><h1>ALPHAS - SEU MUNDO VIRTUAL</h1></header>
        <nav id="cxamigo">
        <h2>Cadastre Amigos<h2>
            <a href="telacadamigos.php">
                <img src="img/amigos.jpg" alt="Amigo">
            </a>
        </nav>
        <nav id="cxcomercio">
        <h2>Cadastre seu comércio<h2>
            <a href="telacadcomecial.php">
                <img src="img/comercio.png" alt="Comércio">
            </a>
        </nav>
        <nav id="cxusuario">
            <h2>Cadastre-se<h2>
            <a href="telacaduser.php">
                <img src="img/cadastro.png" alt="Usuário">
            </a>
        </nav>
        <nav id="cxconsultaamigo">
        <h2>consulte Amigo<h2>
            <a href="telacadamigos.php">
                <img src="img/amigos.jpg" alt="Consulta Amigo">
            </a>
        </nav>
        <nav id="cxconsultacomercio">
        <h2>consulte Comércio<h2>
            <a href="telacadcomecial.php">
                <img src="img/comercio.png" alt="Consulta Comércio">
            </a>
        </nav>
        <nav id="cxconsultauser">
        <h2>consulte Usuário<h2>
            <a href="telacaduser.php">
                <img src="img/cadastro.png" alt="Consulta Usuário">
            </a>
        </nav>
     
        <footer id="rodape"><h2>&copy Bruna <h2></footer>
        
    </section>
</body>
</html>
