<?php

    $server ="localhost";
    $user ="root";
    $senha ="";
    $banco ="bdteste";
    $conn = mysqli_connect(
        $server, $user, $senha, $banco
    );

?>