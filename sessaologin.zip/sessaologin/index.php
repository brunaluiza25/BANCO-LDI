<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INDEX</title>
</head>
<body>
    <fieldset>
        <legend>Acesso ao Sitema</legend>
<form action="open.php" method="POST">
    Login:<br/>
    <input type="email" name="cxlogin"/><br/>
    Senha:</br>
    <input type="password" name="cxsenha"/><br/>
    <input type="submit" name="Acessar"/>
</form>
</fieldset>
</body>
</html>